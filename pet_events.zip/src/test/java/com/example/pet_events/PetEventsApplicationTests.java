package com.example.pet_events;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PetEventsApplicationTests {

	@Test
	void contextLoads() {
	}

}
