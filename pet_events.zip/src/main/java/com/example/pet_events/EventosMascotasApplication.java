package com.example.pet_events;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class EventosMascotasApplication {

	public static void main(String[] args) {
		SpringApplication.run(EventosMascotasApplication.class, args);
	}

}
